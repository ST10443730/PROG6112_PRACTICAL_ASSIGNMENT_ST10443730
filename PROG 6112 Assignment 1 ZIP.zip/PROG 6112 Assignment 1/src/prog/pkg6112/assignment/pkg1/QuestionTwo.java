/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog.pkg6112.assignment.pkg1;

import java.util.Scanner;

/**
 *
 * @author konim
 */
public class QuestionTwo {

    // attributes and feature of hairstyles I chose
    private String length;
    private int quantity;
    private String colour;
    private String thickness;
    private boolean TiedUp;
    private boolean letLoose;

    public void Hairstyles (String length, int quantity, String colour, String thickness, boolean tiedUp, boolean LetLoose) {
        this.length = length;
        this.quantity = quantity;
        this.colour = colour;
        this.thickness = thickness;
        this.TiedUp = TiedUp;
        this.letLoose = letLoose;
    }

    // Getters and Setters 
    public String getLength() {
        return length;
    }

    public void setLength(String lenght) {
        this.length = length;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public String getThickness() {
        return thickness;
    }

    public boolean isTiedUp() {
        return TiedUp;
    }

    public void setTiedUp(boolean tiedUp) {
        this.TiedUp = tiedUp;
    }

    public boolean isLetLoose() {
        return letLoose;
    }

    public void setLetLoose(boolean letLose) {
        this.letLoose = letLoose;
    }

    @Override

    public String toString() {
        return " Hairstyle {"
                + "length = " + length + '\''
                + " , quantity = " + quantity
                + " , colour = " + colour + '\''
                + " thickness = " + thickness + '\''
                + " , tiedUp = " + TiedUp
                + ", letLoose = " + letLoose
                + '}';
    }

public class BoxBraids extends Hairstyle {

    public BoxBraids(String Length, int quantity, String colour, String thickness, boolean tiedUp, boolean letLoose) {
        super(length, quantity, colour, thickness, tiedUp, letLoose);
    }

    @Override
    public String toString() {
        return "BoxBraids{" + super.toString() + "}";
    }
}

public class SenegaleseTwist extends Hairstyles {

    public SenegaleseTwist(String Length, int quantity, String colour, String thickness, boolean tiedUp, boolean letLoose) {
        super(length, quantity, colour, thickness, tiedUp, letLoose);
    }

    @Override
    public String toString() {
        return "SenegaleseTwist{" + super.toString() + "}";
    }
    }

public class FulaniBraids extends Hairstyles {

    public FulaniBraids(String Length, int quantity, String colour, String thickness, boolean tiedUp, boolean letLoose) {
        super(length, quantity, colour, thickness, tiedUp, letLoose);
    }

    @Override
    public String toString() {
        return "FulaniBraids{" + super.toString() + "}";
    }
}

public class FauxLocs extends Hairstyles {

    public FauxLocs(String Length, int quantity, String colour, String thickness, boolean tiedUp, boolean letLoose) {
        super(length, quantity, colour, thickness, tiedUp, letLoose);
    }

    @Override
    public String toString() {
        return "FauxLocs{" + super.toString() + "}";
    }
}

private static void addNewHairstyles( Scanner scanner){
    System.out.println("\n Select Hairstyle Type: ");
    System.out.println(" 1. Box Braids");
    System.out.println(" 2. Knotless Braids");
    System.out.println(" 3. Senegalese Twists");
    System.out.println(" 4. Fulani Braids");
    System.out.println(" 5. Faux Locs");
    System.out.println(" Choose a hairstyle");
    int type = scanner.nextInt();
    
    System.out.println(" Enter length: ");
    String length = scanner.nextLine(); 
    
    System.out.println(" Enter quantity: ");
        String quantity = scanner.nextLine(); 
    scanner.nextLine(); 
    
    System.out.println(" Enter colour: ");
    String colour = scanner.nextLine(); 
    
    System.out.println(" Enter thickness: ");
    String thickness = scanner.nextLine(); 
    
    System.out.println(" Is it tied up? (true/false) : ");
    boolean tiedUp = scanner.nextBoolean(); 
    
    System.out.println(" Is it let loose (true/false) : ");
 boolean letLoose = scanner.nextBoolean(); 
 
 Hairstyle hairstyle = null;

        switch (type) {
            case 1:
                Hairstyles = new BantuKnots(length, quantity, color, thickness, TiedUp, letLoose);
                break;
                
            case 2:
                Hairstyles = new BoxBraids(length, quantity, color, thickness, TiedUp, letLoose);
                break;
                
            case 3:
                Hairstyles = new KnotlessBraids(length, quantity, color, hickness, TiedUp, letLoose);
                break;
                
            case 4:
                Hairstyles = new SenegaleseTwists(length, quantity, color, thickness, TiedUp, letLoose);
                break;
                
            case 5:
                Hairstyle = new FulaniBraids(length, quantity, color, thickness, TiedUp, letLoose);
                break;
                
            case 6:
                Hairstyles = new FauxLocs(length, quantity, color, thickness, TiedUp, letLoose);
                break;
                
            default:
                System.out.println("Invalid hairstyle type.");
                return;
        }

        Hairstyles.add(hairstyle);
        System.out.println("Hairstyle added successfully!");
    }

    private static void displayHairstyles() {
        System.out.println("\n=== List of Hairstyles ===");
        for (Hairstyle hairstyle : hairstyles) {
            System.out.println(hairstyle);
        }
    }
}


