
package prog.pkg6112.assignment.pkg1;

import java.util.Scanner;
import static prog.pkg6112.assignment.pkg1.PROG6112Assignment1.scanner;
import static prog.pkg6112.assignment.pkg1.PROG6112Assignment1.students;

public class Student {
    private String ID; 
            private String Name; 
            private int Age; 
            private String Email; 
            private String Course; 
            
            public Student ( String ID, String Name, int Age, String Email, String Course ){
            this.ID = ID; 
            this.Age = Age; 
            this.Course = Course; 
            this.Email = Email; 
            this.Name = Name; 
            
            
            }

    public String getID() {
        return ID;
    }
            
            @Override 
            public String toString(){
            return "ID: " + ID + ", Name: " + Name + ", Age: " + Age + " , Email: " + Email + " Course: " + Course; 
            }
            
             public static void SaveStudent() {
        Scanner scanner = new Scanner(System.in);
        System.out.println(" \n CAPTURE A NEW STUDENT");
        System.out.println(" *************************** ");

        System.out.print(" Enter Student ID: ");

        String ID = scanner.nextLine();

        System.out.print(" Enter Student Name :");

        String Name = scanner.nextLine();

        int Age = 0; int ageInput;
        while (true) {
            System.out.print("Enter Student Age");
            ageInput = scanner.nextInt();
            scanner.nextLine();
            if (StudentAge(ageInput)){break;}
        }
        Age = ageInput;
        System.out.print(" Enter student Email: ");
        String Email = scanner.nextLine();

        System.out.print(" Enter student course: ");
        String Course = scanner.nextLine();

        // Create a new student object and add it to the list 
        students.add(new Student(ID, Name, Age, Email, Course));
        System.out.println(" Student details captured successfully. ");

    }
             public static boolean StudentAge(int ageInput){
             try {

                if (ageInput >= 16){
                    return true;
                } else {
                    System.out.println(" You have entered an incorrect student age!!!");
                    System.out.println(" Please re-enter the student age >> ");
                    return false;
                }
            } catch (NumberFormatException e) {
                System.out.println(" You have entered the incorrect student age ");
                System.out.println(" Pleases re enter the student age>>");
                return false;
            }
             }

    public static void SearchStudent(String ID) {
       if(ID.equals(null)) {System.out.println(" Enter Student ID to search");
        ID = scanner.nextLine();}

        Student FoundStudent = null;
        for (Student student : students) {
            if (student.getID().equals(ID)) {
                 FoundStudent = student;
                break;
            }
        }
        if (FoundStudent != null) {
            System.out.println(FoundStudent);
        } else {
            System.out.println(" Student with student ID: " + ID + "was not found!");
        }
       
    }

    public static void DeleteStudent(String ID) {
        if (ID.equals(null))
        {System.out.println(" Enter the student ID to delete: ");
         ID = scanner.nextLine();}

        Student foundStudent = null;
        for (Student student : students) {
            if (student.getID().equals(ID)) {
                foundStudent = student;
                break;
            }
        }

        if (foundStudent != null) {
            students.remove(foundStudent);
            System.out.println("Student with student ID " + ID + " Has been deleted");
        } else {
            System.out.println(" Student with ID : " + ID + " was not found");
        }
      
    }

    public static void StudentReport() {
        System.out.println(" \n STUDENT REPORT");
        System.out.println(" *********************************** ");
        if (students.isEmpty()) {
            System.out.println(" No student available to display. ");
        } else {
            for (Student student : students) {
                System.out.println(student);
                System.out.println("----------------------------");
            }
        }
    }
}


