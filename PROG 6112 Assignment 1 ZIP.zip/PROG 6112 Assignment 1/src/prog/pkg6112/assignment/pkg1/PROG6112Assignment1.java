package prog.pkg6112.assignment.pkg1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import prog.pkg6112.assignment.pkg1.Student;

public class PROG6112Assignment1 {
// Arraylist for students

    static ArrayList<Student> students = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            // Main Menu displaying 
            System.out.println(" STUDENT MANAGEMENT APPLICATION ");
            System.out.println(" ************************************ ");
            System.out.println(" Please enter '1' to launch the menu or any other key to exit: ");
            String input = scanner.nextLine();

            if (!input.equals("1")) {
                System.out.println("Now exiting the application, ggodbye!");
                break;
            }
            DisplayMenu();
        }
        
        Scanner scanner = new Scanner ( System.in); 
        int option; 
        
        do{
            System.out.println(" \n=== Hairstyle Management Menu ===");
            System.out.println(" 1. Add New Hairstyle");
            System.out.println(" 2. Display all Hairstyles");
            System.out.println(" 3. Exit");
            System.out.println(" Choose an option");
            option = scanner.nextInt(); 
            scanner.nextLine(); 
            switch (option){
                case 1: addNewHairstyle(scanner); 
                break; 
                
                case 2: 
                    displayHairstyles(); 
                    break; 
                    
                case 3: 
                    System.out.println(" Exiting the application...");
                    break; 
                    
                default: 
                    System.out.println(" Invalid option. Please try again. ");
            }
        } while ( option ! = 3); 
        
        scanner.close();
    }
    
    private static void addNewHairstyle(Scanner scanner){
    
    }
//class for menu display

    public static void DisplayMenu() {

        Scanner scanner = new Scanner(System.in);
        int choice = -1;
        // While loop that will keep showing the main menu until the user exits the application
        while (choice != 5) {
            // The menu's options 
            System.out.println(" \n Please select one of the following options");
            System.out.println(" (1) Capture a new student ");
            System.out.println(" (2) Search for a student ");
            System.out.println(" (3) Delete a student ");
            System.out.println(" (4) Print student report");
            System.out.println(" (5) Exit Application ");
            System.out.println(" Enter your choice: ");

            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        Student.SaveStudent();
                        break;
                    case 2:
                            Student.SearchStudent(null);
                        break;
                    case 3:
                        Student.DeleteStudent(null);
                        break;
                    case 4:
                        Student.StudentReport();
                        break;
                    case 5:
                        System.out.println(" Now exiting the apllication");
                        return;
                    default:
                        System.out.println("Chocie is invalid, please try again");
                }

            } else {
                System.out.println("Invalid choice, please try again.");
                break;
            }
        }
    }
}
        

   