/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package prog.pkg6112.assignment.pkg1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import static prog.pkg6112.assignment.pkg1.PROG6112Assignment1.students;

/**
 *
 * @author konim
 */
public class StudentTest {
    
    public StudentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }

    @After
    public void tearDown() throws Exception {
    }
    
    
    @Test
    public void testGetID() {
        System.out.println("getID");
        Student instance = null;
        String expResult = "";
        String result = instance.getID();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of toString method, of class Student.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Student instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testSaveStudent() {
        System.out.println("SaveStudent");
        students.add(new Student("1234", "Serena",35 , "tennisrock25@gmail.com" , "Sport Science"));
        assertTrue(students.size() >= 1);
      
    }

    /**
     * Test of SearchStudent method, of class Student.
     */
    @Test
    public void testSearchStudent() {
        System.out.println("SearchStudent");
        students.add(new Student("1234", "Serena",35 , "tennisrock25@gmail.com" , "Sport Science"));
        Student.SearchStudent("1234");
       
    }

    /**
     * Test of DeleteStudent method, of class Student.
     */
    @Test
    public void testDeleteStudent() {
        System.out.println("DeleteStudent");
                students.add(new Student("1234", "Serena",35 , "tennisrock25@gmail.com" , "Sport Science"));

        Student.DeleteStudent("1234");
        
    }

       @Test
    public void testStudentReport() {
        System.out.println("StudentReport");
        Student.StudentReport();
       
    }

    /**
     * Test of StudentAge method, of class Student.
     */
    @Test
    public void testStudentAge() {
        System.out.println("StudentAge");
        int ageInput = 0;
        boolean expResult = false;
        boolean result = Student.StudentAge(ageInput);
        assertEquals(expResult, result);
        
    }
    
}
